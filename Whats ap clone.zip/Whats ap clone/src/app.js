import { WhatsAppController } from './controller/WhatsAppController.js';

window.app = new WhatsAppController();